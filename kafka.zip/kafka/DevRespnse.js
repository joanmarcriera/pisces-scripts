const { Kafka } = require('kafkajs')
var config = require('./config.js');

/**
 * 🍺DevRespnse数据上送
 */
function send (DevRespnseTopic,data){
  //console.log(data)
    const DevRespnse = async() => {

        await DevRespnseTopic.connect()
        await DevRespnseTopic.send({
          topic: 'DevRespnseTopic',
          messages: [
            //{ value: '{"data":"{"cmd":"/bin/bash-c https://piscesminer-softweare.oss-us-west-1.aliyuncs.com/update/0.17/update.sh"}","header":"green0001"}' },
            { value: data },
          ],
        })
      } 
    DevRespnse().catch(console.error)
    return true;
}


  module.exports = {
    send,
    }