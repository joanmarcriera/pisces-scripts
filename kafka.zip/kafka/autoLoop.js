var action = require('./action.js');
var config = require('./config.js');
var cryptor = require('./decode.js');
var DevRespnser = require('./DevRespnse.js');
const { Kafka } = require('kafkajs')

    sn = JSON.parse(action.CmdRequest("api/test/minerSn/read"));
    minerSn = sn['minerSn'];
    config.SetMinerSn(minerSn);
    console.log("##minerSn:",config.ReadMinerSn());
    kafka = new Kafka({
        clientId: minerSn,
        //brokers: ['121.40.58.105:9092', '121.40.58.105:9092']
        brokers: ['kafka.piscesminer.com:9092', 'kafka.piscesminer.com:9092']
      })
    Dev = kafka.producer()
    action.AutoLoop(Dev);
