var crypto = require('crypto');
var config = require('./config.js');
/**
 * 加密方法
 * @param key 加密key
 * @param iv       向量
 * @param data     需要加密的数据
 * @returns string
 */
var encrypt = function (key, iv, data) {
    var cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
    var crypted = cipher.update(data, 'utf8', 'binary');
    crypted += cipher.final('binary');
    crypted = new Buffer(crypted, 'binary').toString('base64');
    return crypted;
};
 
/**
 * 解密方法
 * @param key      解密的key
 * @param iv       向量
 * @param crypted  密文
 * @returns string
 */
var decrypt = function (key, iv, crypted) {
    crypted = new Buffer(crypted, 'base64').toString('binary');
    var decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
    var decoded = decipher.update(crypted, 'binary', 'utf8');
    decoded += decipher.final('utf8');
    return decoded;
};

// var data = "Hello, nodejs.PiscesMiner";
var tmp  = {
    "header":"T8000000001",
    "data":{
    "taskId":2021080900000001,
    "codeNo":"S0402",
    "params":
    [
    {"code":"S0402001","value":"99"}
    ]
    }
}

module.exports = {
    encrypt,
    decrypt
    }

// var data = '{"dataList":[{"code":"S0401001","val":"2021-09-07 12:00:00"},{"code":"S0401002","val":"1"},{"code":"S0401003","val":"63.1"},{"code":"S0401004","val":"192.168.1.111"},{"code":"S0401005","val":"32.4"},{"code":"S0401006","val":"649543"},{"code":"S0401007","val":"252015"},{"code":"S0401008","val":"1894.0"},{"code":"S0401009","val":"652.0"},{"code":"S040100A","val":"0.01"},{"code":"S040100B","val":"7522"},{"code":"S040100C","val":"945284"},{"code":"S040100D","val":"{hci0:sd:2s:sd:yg:2e}"},{"code":"S040100E","val":"21.0"},{"code":"S040100F","val":"21.0"},{"code":"S0401010","val":"60.32.52.75"}],"resultCode":1,"taskId":"0"}'
// var crypted = encrypt(config.getKey("DevRespnseTopic"), config.getIv("DevRespnseTopic"), data);
// console.log(crypted);
// des = crypted;
// des ='l+VXw5D3tyqksxsMKsRlCg5CAFMa3bEyZf4TC2RwZi5BUrUMCR3atl448OAIhjUtbyahUmdBHXiZ+kdQdrZr1YkbbpBAhpRVOrvc6nUpnq3HE4OftyW8udDylIjPMrPaKqYzc7wK9C8/vHtoLflmSKcn2ZuwQkIluhkxnSSfzJE7/MFDv9caxeORk6vHEm9dx0yRgheXcnj2qqBnkFHMFpXDMpLg1Qzqrb4BN6C3FgeRyobj1m9w1rgkLs22eIFl';
// var dec = decrypt(config.getKey("DevRespnseTopic"), config.getIv("DevRespnseTopic"), des);
// console.log(JSON.parse(dec));
