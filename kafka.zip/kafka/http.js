var http = require('http')
var querystring = require('querystring');
var express = require('express')
var app = express()

var bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.listen(8002, function() {
  console.log('start')
})
app.post('/cmd', function(req, res) {
  console.log('收到post请求了')
  var query = req.query
  console.log(query)
  console.log(query.cmd)
  var shell = CmdRunner(query.cmd)
  res.send(shell);
  res.end();
})

app.post('/asyncCmd', function(req, res) {
  console.log('收到post请求了')
  var query = req.query
  console.log(query)
  console.log(query.cmd)
  ret = {"code":200 , "data":true}
  res.send(ret);
  res.end();
  CmdAsync(query.cmd)
})

app.get('/', function(req, res) {
  console.log('收到get请求了')
  res.send(responser);
  res.end();
})



var responser = {"code":501 , "status":"offline"};

function setResponse(code,data){
  responser = {"code":code , "status":data};
}

function CmdRunner(cmd) {
  var exec = require('child_process').execSync;
  var str = exec(cmd);
  return (str.toString("utf8").trim());
}

const CmdAsync = async (cmd) => {
  var exec = require('child_process').execSync;
  var str = exec(cmd);
  return (str.toString("utf8").trim());
}
module.exports = {
  setResponse
  }
