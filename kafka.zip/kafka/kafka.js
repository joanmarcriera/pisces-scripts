const { Kafka } = require('kafkajs')
var config = require('./config.js');
var cryptor = require('./decode.js');
var action = require('./action.js');
var DevRespnser = require('./DevRespnse.js');
//var httpServer = require('./http.js');
var minerSn;
var kafka;

var DevRespnseTopic;
var DevUpgradeTopic;
var WebRequestTopic;

/**
 * 🍺WebRequestTopic 接收
 */
const WebRequest = async () => {
  await WebRequestTopic.connect()
  await WebRequestTopic.subscribe({ topic: 'WebRequestTopic', fromBeginning: true })

  await WebRequestTopic.run({
    eachMessage: async ({ topic, partition, message }) => {
      // console.log({
      //   partition,
      //   offset: message.offset,
      //   value: message.value.toString(),
      // })
      console.log("## Got WebRequest")
      action.WebRequestRouter(DevRespnseTopic,message.value.toString());
    },
  })
}

/**
 * 🍺DevUpgradeTopic接收
 */
const DevUpgrade = async () => {
  await DevUpgradeTopic.connect()
  await DevUpgradeTopic.subscribe({ topic: 'DevUpgradeTopic', fromBeginning: true })

  await DevUpgradeTopic.run({
    eachMessage: async ({ topic, partition, message }) => {
      // console.log({
      //   partition,
      //   offset: message.offset,
      //   value: message.value.toString(),
      // })
      console.log("## Got Upgrade")
      action.UpgradeRouter(DevRespnseTopic,message.value.toString());
    },
  })
}


/**
 * 🍺DevRespnse数据上送
 */
// const DevRespnse = async() => {

//   await DevRespnseTopic.connect()
//   await DevRespnseTopic.send({
//     topic: 'DevRespnseTopic',
//     messages: [
//       //{ value: '{"data":"{"cmd":"/bin/bash-c https://piscesminer-softweare.oss-us-west-1.aliyuncs.com/update/0.17/update.sh"}","header":"green0001"}' },
//       { value: '{"data":"tPzQjnsSdXyoyQpsk/jxeezAKZJNejepd5AoEqmXyHR9ACf6E5On0SgMshJnk6OK62uPVgTcGZdIGBa3kqFAt7+Nu8zVFZwqXY85l3C60s+WCE+NR/Tom7XI7XoPhBNy8K9vY620S+yF4CCkIGyCOaNJe+hODTEo4jUdzRhHaJJ5kstNOwQJb64/BL6u00gyUGaNMqRxwNp5c1XcEvthoZa/timqJpHcnYhbtouY1m4CSKdU3zJZm9T8vCBxe43ceQtuWzrEco2VJFExFjq83N1JeIDHA8K+uuzTYxlt/0Od2xnaB2GBTkyo9iIRlHpTqGq4G/LxawerS44aFcA+uPiMKj2StugZlxiyg/k2X+Gvh/RczbNWX0yNLuHQq5yKu6glRttfFTPVnp8fKalFr2mZVJJk6Fvcmnb6S4Hq5Rez67x+Q6AGr/dkfEKi+Eaa84WkwTdJbDkt7pCXTAe3lXethZkSQl2M60pUBNZGDZdTkPPdrjc5Npeo+psAuRsWdsMWpDV60Bm6ITQFY6FHuMLyvUNVL+dLeURRBD00RkgCYcHVlMNq4JNQcV7z5dadyxW99i3M+5i0StiRiH7/SQLe48A+Bu4pUWL7UfftF6jaMuL5jv4ndLdnitiz3U3EpUwfngh7Uu9c8HYY2iAIkTOooTfWrkTzBKsmioa+IObnr39vWyYHuABkRunhSV8mWK8Utah+ua1xqKEMqmX0ecO3iGSd6EHa5jcWQrUWVX57yddD6Txhm3zmQmyOfEIbaDIssDHSyAo/puSZsDRCXpCgBKwLJRI+11t1CBv1t5Xz3RhbBevVZXXj2Y1+Rw6HlueEsT3CMOyWZgAYYjFLKg==","header":"green0001"}' },
//     ],
//   })
// }
/**
 * 🍺初始化程序
 */

 ListenDevUpgrade = async function (target){
  DevUpgrade().catch(console.error)
}

ListenWebRequest = async function (target){
  WebRequest().catch(console.error)
}

function init(){
  //🚀init minerSn
  try{
    sn = JSON.parse(action.CmdRequest("api/test/minerSn/read"));
    minerSn = sn['minerSn'];
    //minerSn = "10047000010062";
    config.SetMinerSn(minerSn);
    console.log("##minerSn:",config.ReadMinerSn());
  }catch(e){
    console.log("无法获取minerSn , retry");
    // TODO 设计规则进行api-ser重启
    action.wait(10)
    init();
  }
  //🚀init object

  kafka = new Kafka({
    clientId: minerSn,
    //brokers: ['121.40.58.105:9092', '121.40.58.105:9092']
    brokers: ['kafka.piscesminer.com:9092', 'kafka.piscesminer.com:9092']
  })
  try{
    DevRespnseTopic = kafka.producer()
    DevUpgradeTopic = kafka.consumer({topic: 'DevUpgradeTopic', groupId: minerSn+"dev" })
    WebRequestTopic = kafka.consumer({topic: 'WebRequestTopic', groupId: minerSn+"web" })
  }catch(e){
    console.log("连接初始化失败,Retry")
    action.wait(10)
    init();
  }
  //🚀init connection
  try{
  // DevUpgrade().catch(console.error)
  // WebRequest().catch(console.error)
  ListenDevUpgrade();
  ListenWebRequest();
  //upgrade.init()
  }catch(e){
    console.log(e)
    console.log("连接初始化失败，请检查网络并重试")
    action.wait(10)
    init();
  }
  //🚀init Http-protect-server
  try{
    //httpServer.setResponse(200,"online")
    //httpServer.statuHttp()
  }catch(e){
    console.log("Http服务错误")
  }
  //🚀循环更新
  try{

    //AutoLoop(DevRespnseTopic)
  }catch(e){

  }






}
init()
