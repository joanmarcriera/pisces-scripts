
var config = require('./config.js');
var cryptor = require('./decode.js');
var DevRespnser = require('./DevRespnse.js');

/**
 * TODO 定时上报
 * TODO 时间超时比对
 * TODO 边界限定
 */


/**
 * 数据下发操作
 * @param {上报目标} target 
 * @param {下发数据值} rawdata 
 */
const WebRequestRouter = async (target,rawdata) => {
    console.log("## Web Request Router")
    
    try{
        data = JSON.parse(rawdata);
        switch(data.header){
            case config.ReadMinerSn():
                console.log("## webrequest active")
                WebRequestAction(target,data.data);
                break;
            case "all" :
                console.log("## webrequest active")
                WebRequestAction(target,data.data)
                break;
            default:
                console.log("not me")
                console.log(data.header)
                console.log(config.ReadMinerSn())
                break;
        }

    }catch(e){
        console.log(e)
    }
}

/**
 * 更新路由
 * @param {上报目标} target 
 * @param {下发数据值} rawdata 
 */
const UpgradeRouter = async (target,rawdata) => {
    data = JSON.parse(rawdata);
    try{
	    console.log(data.header)
        switch(data.header){
            case "all":
                UpgradeFirmware(target,data.data);
                break;
            case config.ReadMinerSn():
                UpgradeFirmware(target,data.data);
                break;
            default:
                console.log("not me")
                break;
        }

    }catch(e){
        console.log(e)
    }
}

/**
 * 进行操作下发的分发
 * @param {WebRequest操作} data 
 */
function WebRequestAction(target,data){
    console.log("## Do WebRequest Action")
    //console.log(data)
    try{
        var raw = cryptor.decrypt(config.getKey("WebRequestTopic"),config.getIv("WebRequestTopic"),data);
        raw = JSON.parse(raw);
        var code = raw.codeNo;
        var taskId = raw.taskId;
        switch(code){
            case "S0401":
            BasicInfoCollector(target,taskId);
                break;
            case "S0402":
            WebRequestCommandRunner(target,raw);
                break;
            default:
                console.log("nothing:")
                console.log(raw)
                break;
        }
    }catch(e){
        console.log(e)
    }
}

/**
 * WebRequest下发指令执行函数
 * @param {发送目标} target 
 * @param {返回值数据} data 
 */
function WebRequestCommandRunner(target,data){
    console.log("## run command")
    try{
        var shell = CmdRunner(data.params.S0A02001);
        var raw = {
            "resultCode":1,
            "taskId":data.taskId,
            "codeNo":"S0402",
            "dataList":[{"code":"S0402001","val":shell}]
        }
        ret = {
            "header":config.ReadMinerSn(),
            "data":cryptor.encrypt(config.getKey("DevRespnseTopic"),config.getIv("DevRespnseTopic"),JSON.stringify(raw))
        }
        //console.log(ret)
        ReportData (target,JSON.stringify(ret))
    }catch(e){
        console.log(data)
        console.log(e)
        var shell = CmdRunner(data.cmd);
        var raw = {
            "resultCode":0,
            "taskId":data.taskId,
            "codeNo":"S0402",
            "dataList":[]
        }
        ret = {
            "header":config.ReadMinerSn(),
            "data":cryptor.encrypt(config.getKey("DevRespnseTopic"),config.getIv("DevRespnseTopic"),JSON.stringify(raw))
        }
        ReportData (target,JSON.stringify(data))
    }
    
    return true
}

/**
 * 进行设备更新操作
 * @param {设备更新} data
 */
function UpgradeFirmware(target,raw){
    
    data = cryptor.decrypt(config.getKey("DevUpgradeTopic"),config.getIv("DevUpgradeTopic"),raw);
    data = JSON.parse(data)
    try{
        var shell = CmdRunner(data.cmd);
    }catch(e){
        console.log(e)
    }
    return true;

}

/**
 * 数据上报程序
 * @param {上报内容} data 
 */
function ReportData(DevRespnseTopic,data){
    DevRespnser.send(DevRespnseTopic,data);
}

  AutoUpStream = async function (target){
    console.log("auto upstreaam")
    BasicInfoCollector(target,0)
    
}

AutoLoop = async function (target){
    AutoUpStream(target)
    setInterval(AutoUpStream, 3600000,target);
}

/**
 * 通过调用python-api实现基础信息收集
 * @param {基础信息收集} data 
 * @returns 
 */
function BasicInfoCollector(target,taskId) {
    console.log("## Active Basic Info Collector")
    try{
        var data = CmdRequest("api/kafka/info");
        var raw = {
            "resultCode":1,
            "taskId":taskId,
            "codeNo":"S0401",
            "dataList":JSON.parse(data)
        }
        ret = {
            "header":config.ReadMinerSn(),
            "data":cryptor.encrypt(config.getKey("DevRespnseTopic"),config.getIv("DevRespnseTopic"),JSON.stringify(raw))
        }
        //console.log(ret)
        ReportData (target,JSON.stringify(ret))
    }catch(e){
        console.log(e)
        var raw = {
            "resultCode":0,
            "taskId":taskId,
            "codeNo":"S0401",
            "dataList":[],
        }
        ret = {
            "header":config.ReadMinerSn(),
            "data":cryptor.encrypt(config.getKey("DevRespnseTopic"),config.getIv("DevRespnseTopic"),JSON.stringify(raw))
        }
        ReportData (target,JSON.stringify(ret))
    }

    return true;
}

/**
 * 调用Shell进行指令运行
 * @param {运行指令} cmd 
 * @returns 
 */
function CmdRunner(cmd) {
    var exec = require('child_process').execSync;
    var str = exec(cmd);
    return (str.toString("utf8").trim());
}

/**
 * 通过curl发起基础的get请求
 * @param {请求地址}} url 
 * @returns 
 */
function CmdRequest(url){
    var baseUrl = "curl http://127.0.0.1:8001/"
    return CmdRunner(baseUrl+url)
}



/**
 * 同步延时等待函数
 * @param {等待秒数} second 
 */
function wait(second) {
    let ChildProcess_ExecSync = require('child_process').execSync;
    ChildProcess_ExecSync('sleep ' + second);
}

//BasicInfoCollector("0","0")
// var min= {"taskId":2021080900000001,"cmd":"uname -a"}
// WebRequestCommandRunner(1,min)
module.exports = {
    CmdRunner,
    CmdRequest,
    WebRequestRouter,
    UpgradeRouter,
    ReportData,
    wait,
    AutoUpStream,
    AutoLoop
    }

    
