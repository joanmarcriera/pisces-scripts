// var data = {"list":[{"code":"S0401001","val":"2021-09-07 12:00:00"},{"code":"S0401002","val":"1"},{"code":"S0401003","val":"63.1"},{"code":"S0401004","val":"192.168.1.111"},{"code":"S0401005","val":"vv"},{"code":"S0401006","val":"64G"},{"code":"S0401007","val":"25G"},{"code":"S0401008","val":"1894.0"},{"code":"S0401009","val":"652.0"},{"code":"S040100A","val":"0.01"},{"code":"S040100B","val":"7522"},{"code":"S040100C","val":"945284"},{"code":"S040100D","val":"{hci0:sd:2s:sd:yg:2e}"},{"code":"S040100E","val":"21.0"},{"code":"S040100F","val":"21.0"},{"code":"S0401010","val":"60.32.52.75"}],"resultCode":1,"taskId":"0"}
// console.log(data);
// console.log(JSON.stringify(data));

var action = require('./action.js');

var exec = require('child_process').exec;
var cmdStr = 'ls';

// exec(cmdStr, function(err,stdout,stderr){
//     if(err) {
//         console.log('get weather api error:'+stderr);
//     } else {
//         /*
//         这个stdout的内容就是上面我curl出来的这个东西：
//         {"weatherinfo":{"city":"北京","cityid":"101010100","temp":"3","WD":"西北风","WS":"3级","SD":"23%","WSE":"3","time":"21:20","isRadar":"1","Radar":"JC_RADAR_AZ9010_JB","njd":"暂无实况","qy":"1019"}}
//         */
//         // var data = JSON.parse(stdout);
//         console.log(stdout);
//     }
// });

// function shell (cmd){
//     var exec = require('child_process').execSync;
//     var str = exec(cmd);
//     return (str.toString("utf8").trim());
// }
console.log(JSON.parse(action.CmdRequest("api")))