var minerSn;
function getKey(type){
    switch(type){
        case "DevUpgradeTopic":
            return "vdl7j1o65hmgw84z";
        case "DevRespnseTopic":
            return "0h48uxpiad16voze";
        case "WebRequestTopic":
            return "0wjoxcigl76fnbk8";
        default:
            return "buhg6ko013yqadxe";
    }   
}
function getIv(type){
    switch(type){
        case "DevUpgradeTopic":
            return "utvlz5fpcx93s40d";
        case "DevRespnseTopic":
            return "t143j6hxdmngr8w9";
        case "WebRequestTopic":
            return "o9jesicd7umgny2h";
        default:
            return "ivjluk8w6z02c3s9";
    }
}

function ReadMinerSn(){
    return minerSn;
}

function SetMinerSn(Sn){
    minerSn=Sn;
    return true;
}
module.exports = {
    getKey,
    getIv,
    ReadMinerSn,
    SetMinerSn
    }